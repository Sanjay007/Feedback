package com.techm.learning.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

public class Feedback {

	@Entity
	@Table(name = "Feedback")
	public class Employee implements Serializable {

		private static final long serialVersionUID = -723583058586873479L;

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "FEEDBACK_ID")
		private Integer feedback_id;

		@Column(name = "COMMENT")
		private String comment;

		public Integer getFeedback_id() {
			return feedback_id;
		}

		public void setFeedback_id(Integer feedback_id) {
			this.feedback_id = feedback_id;
		}

		public String getComment() {
			return comment;
		}

		public void setComment(String comment) {
			this.comment = comment;
		}

	}
}
