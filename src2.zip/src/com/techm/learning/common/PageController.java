package com.techm.learning.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.techm.learning.util.LogUtil;

@Controller
public class PageController {

	private static final Logger logger = LoggerFactory
			.getLogger(PageController.class);

	/*
	 * @RequestMapping("/manager_login") public ModelAndView
	 * getManagerLoginPage() { return new
	 * ModelAndView("registration/manager_login"); }
	 */

	/*
	 * @RequestMapping("/feedback") public ModelAndView getFeedbackPage() {
	 * return new ModelAndView("feedback_page"); }
	 */

	@RequestMapping("/manager_login")
	public String getManagerLoginPage() {
		LogUtil.debug(logger,
				"***Manager page method called ********************", null);
		return "registration/loginPage";
	}

	@RequestMapping("/feedback")
	public String getFeedbackPage() {
		LogUtil.debug(logger,
				"***Feedback page method called ********************", null);
		return "feedback";
	}

	@RequestMapping(value = "admin", method = RequestMethod.GET)
	public String getAdminLoginPage() {
		LogUtil.debug(logger,
				"***Admin Login page method called ********************", null);
		return "admin/adminLogin";
	}

	
}
