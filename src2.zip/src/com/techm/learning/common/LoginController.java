package com.techm.learning.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.techm.learning.bean.Login;
/*import com.techm.learning.usermgmt.UserService;
import com.techm.learning.usermgmt.User;*/
import com.techm.learning.util.LogUtil;

@Controller
public class LoginController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	/*
	 * @Autowired public UserService userService;
	 */

	@RequestMapping(value = "adminLogin", method = RequestMethod.POST)
	public String processAdminLogin(@ModelAttribute("loginModel") Login login) {

		LogUtil.debug(logger, "***Admin Login post method called ********************", null);

		System.out.println(login.getUsername());
		System.out.println(login.getPassword());

		return "admin/base_site";
		// return "feedback";
	}
}
