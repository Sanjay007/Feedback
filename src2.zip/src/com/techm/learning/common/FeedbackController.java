package com.techm.learning.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.techm.learning.bean.Feedback;
import com.techm.learning.util.LogUtil;

@SessionAttributes("feedbackModel")
@Controller
public class FeedbackController {

	private static final Logger logger = LoggerFactory.getLogger(PageController.class);

	@RequestMapping(value = "feedback", method = RequestMethod.POST)
	public String getFeedback(@ModelAttribute("feedbackModel") Feedback feedback) {
		System.out.println("i am here");
		LogUtil.debug(logger, "***Feedback post method called ********************", null);

		System.out.println(feedback.getComment1());

		return "success";
	}

}
