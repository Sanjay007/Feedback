package com.techm.learning.bean;

public class Feedback {

	private String comment1;

	public String getComment1() {
		return comment1;
	}

	public void setComment1(String comment1) {
		this.comment1 = comment1;
	}

}
